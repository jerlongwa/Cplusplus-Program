/*
 * Developer: Jeremiah Longwa
 * Date: December 20, 2024
 * Purpose: The program tracks items and analyzes the text records they generate throughout the day. 
 * These records list items purchased in chronologicalorder from the time the store opens to the time it closes.
 */
#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

class ItemTracker {
private:
    map<string, int> itemFrequency;
    string dataFilePath;

public:
    // Constructor initializes the data file path
    ItemTracker() : dataFilePath("frequency.dat") {}

    // Processes the input file and populates the item frequency map
    void processInputFile(const string& filePath) {
        ifstream inputFile(filePath);
        string item;

        if (inputFile.is_open()) {
            while (getline(inputFile, item)) {
                if (!item.empty()) { // Check if the line is not empty
                    itemFrequency[item]++;
                }
            }
            inputFile.close();
        } else {
            cerr << "Error: Unable to open file " << filePath << endl;
        }
    }

    // Saves the frequency data to an output file
    void saveDataToFile() {
        ofstream outputFile(dataFilePath);

        if (outputFile.is_open()) {
            for (const auto& pair : itemFrequency) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close();
            cout << "Data saved to " << dataFilePath << endl;
        } else {
            cerr << "Error: Unable to create output file " << dataFilePath << endl;
        }
    }

    // Prints the item frequencies to the console
    void printItemFrequency() const {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " " << pair.second << endl;
        }
    }

    // Prints a histogram of item frequencies
    void printHistogram() const {
        for (const auto& pair : itemFrequency) {
            cout << pair.first << " ";
            cout << string(pair.second, '*') << endl; // Repeats '*' pair.second times
        }
    }
    void run() {
        string userInput;
        int choice;

        while (true) {
            cout << "Menu Options:" << endl;
            cout << "1. Look up item frequency" << endl;
            cout << "2. Print item frequency list" << endl;
            cout << "3. Print item frequency histogram" << endl;
            cout << "4. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
                case 1:
                    cout << "Enter item name: ";
                    cin >> userInput;
                    if (itemFrequency.find(userInput) != itemFrequency.end()) {
                        cout << userInput << " appears " << itemFrequency[userInput] << " times." << endl;
                    } else {
                        cout << userInput << " not found." << endl;
                    }
                    break;
                case 2:
                    printItemFrequency();
                    break;
                case 3:
                    printHistogram();
                    break;
                case 4:
                    return;
                default:
                    cout << "Invalid choice. Please try again." << endl;
            }
        }
    }
};

// Example usage
int main() {
    ItemTracker tracker;
    tracker.processInputFile("CS210_Project_Three_Input_File.txt");
    tracker.run();
    tracker.saveDataToFile();
    return 0;
}