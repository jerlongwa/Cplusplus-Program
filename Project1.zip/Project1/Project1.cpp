/*
 * Developer: Jeremiah Longwa
 * Date: November 17, 2024
 * Purpose: This application displays two clocks simultaneously, one in 12-Hour format  *  and the other in a 24-Hour and allow for user to 
 * input initial time and also able to add hours, minutes and seconds.
 */
#include <iostream>  
#include <iomanip>   
using namespace std;  

// Clock class definition
class Clock {
private:
    int hours;    // Variable to store hours
    int minutes;  // Variable to store minutes
    int seconds;  // Variable to store seconds

public:
    // Constructor to initialize hours, minutes, and seconds
    Clock(int h = 0, int m = 0, int s = 0) : hours(h), minutes(m), seconds(s) {}

    // Function to add time to the clock
    void addTime(int h = 0, int m = 0, int s = 0) {
        seconds += s;  // Add seconds
        if (seconds >= 60) {  // If seconds exceed 60, convert to minutes
            minutes += seconds / 60;
            seconds %= 60;  // Remainder seconds
        }

        minutes += m;  // Add minutes
        if (minutes >= 60) {  // If minutes exceed 60, convert to hours
            hours += minutes / 60;
            minutes %= 60;  // Remainder minutes
        }

        hours += h;  // Add hours
        hours %= 24;  // Ensure hours are within 24-hour format
    }

    // Function to display time in both 12-hour and 24-hour formats
    void displayTime() const {
        
        // Display time in 24-hour format
        cout<<"\n\n*************************" << endl;
        cout << "*     24-Hour Clock\t*" <<endl; 
        cout << "*       " << setw(2) << setfill('0') << hours << ":"
             << setw(2) << setfill('0') << minutes << ":"
             << setw(2) << setfill('0') << seconds << "    \t*"<< endl;
        cout<<"*************************" << endl;
        
        // Convert to 12-hour format
        int displayHour = hours % 12;
        if (displayHour == 0) displayHour = 12;  // Adjust for 12 AM/PM
        string period = (hours < 12) ? "AM" : "PM";  // Determine AM/PM

        // Display time in 12-hour format
        cout<<"\n\n*************************" << endl;
        cout << "*     12-Hour Clock\t*" <<endl; 
        cout << "*      " << setw(2) << setfill('0') << displayHour << ":"
             << setw(2) << setfill('0') << minutes << ":"
             << setw(2) << setfill('0') << seconds << " " << period << "    \t*" << endl;
        cout<<"*************************" << endl;     
             
    }
};

// Function to display user menu and handle user input
void userMenu(Clock& clock) {
    while (true) {
        // Display menu options
        cout<<"\n\n*************************" << endl;
        cout << "*1. Add one hour\t*" << endl;
        cout << "*2. Add one minute\t*" << endl;
        cout << "*3. Add one second\t*" << endl;
        cout << "*4. Exit Program\t*" << endl;
        cout<<"*************************" << endl;
        cout << "Enter your choice: ";
        int choice;
        cin >> choice;  // Get user choice

        // Handle user choice
        switch (choice) {
            case 1:
                clock.addTime(1, 0, 0);  // Add one hour
                break;
            case 2:
                clock.addTime(0, 1, 0);  // Add one minute
                break;
            case 3:
                clock.addTime(0, 0, 1);  // Add one second
                break;
            case 4:
                return;  // Exit the loop
            default:
                cout << "Invalid choice. Please try again." << endl;
        }

        clock.displayTime();  // Display updated time
    }
}

int main() {
    int h, m, s;
    // Prompt user for initial time
    cout << "Enter initial hours: ";
    cin >> h;
    cout << "Enter initial minutes: ";
    cin >> m;
    cout << "Enter initial seconds: ";
    cin >> s;

    // Create Clock object with user-provided initial time
    Clock clock(h, m, s);
    clock.displayTime();  // Display initial time
    userMenu(clock);  // Display menu and handle user input

    return 0;
}